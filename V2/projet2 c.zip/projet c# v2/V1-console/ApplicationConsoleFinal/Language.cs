﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projet
{
    // a global attribute that will be used for the language of the program
    public class Language 
    {
        public static string language;
    }
}