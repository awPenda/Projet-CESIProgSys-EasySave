﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projet
{
    class Work
    {
        public static string filePath = @"..\..\..\work.json";
        public string name { get; set; }
        public string repS { get; set; }
        public string repC { get; set; }
        public string type { get; set; }
    }
}